# walawow_protocol
Walawow Protocol Frontend - The Perpetual Wealth Aggregator on Solana
